Make sure to leave the 2 'static' & 'templates' folder for the webgui to work correctly

On release version they will be auto installed into a temp dir