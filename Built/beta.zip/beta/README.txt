Make sure to have the 2 'static' & 'templates' folders inside the same folder as the server script for the webgui to work correctly on full release version they will be auto installed into a temp dir


Auto undeleteable backdoor & anti debug will be added in full release version so make sure to not run the client payload inside any AV