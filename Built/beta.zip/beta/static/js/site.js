/* Copy Command */
function copyCommand(elementID) {
  navigator.clipboard.writeText(elementID);
}
